module goide

go 1.26.4

require (
	github.com/atotto/clipboard v0.1.4
	github.com/gdamore/tcell/v2 v2.13.10
	github.com/rivo/tview v0.42.0
)

require (
	github.com/gdamore/encoding v1.0.1 // indirect
	github.com/lucasb-eyer/go-colorful v1.3.0 // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	golang.org/x/sys v0.38.0 // indirect
	golang.org/x/term v0.37.0 // indirect
	golang.org/x/text v0.31.0 // indirect
)
